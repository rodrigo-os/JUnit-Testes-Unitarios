package entities;
public class RealModelo extends AbstractModelo {
    public RealModelo(String modelo) {
        this.modelo = modelo;
    }

    @Override
    public String getModelo() {
        return modelo;
    }
}