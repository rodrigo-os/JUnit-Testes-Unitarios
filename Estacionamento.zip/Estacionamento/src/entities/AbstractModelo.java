package entities;
public abstract class AbstractModelo {
    protected String modelo;

    public abstract String getModelo();
}
