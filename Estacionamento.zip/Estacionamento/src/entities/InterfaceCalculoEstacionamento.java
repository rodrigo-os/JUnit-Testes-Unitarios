package entities;
import java.util.List;

public interface InterfaceCalculoEstacionamento {
    public double calcular(List<Double> horas);
}
