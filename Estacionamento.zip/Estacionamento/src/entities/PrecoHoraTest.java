package entities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

class PrecoHoraTest {

static List<Double> precos = new ArrayList<Double>();
static List<Double> horas = new ArrayList<Double>();
static PrecoHora preco = new PrecoHora(precos);
	
	
	@BeforeAll
	static void inserirHoras() {
		horas.add(2.0);
		horas.add(3.0);
		horas.add(1.0);
	}
	
	@BeforeEach
	void inserirPrecos() {
		precos.add(3.00);
		precos.add(2.00);
		precos.add(2.00);
	}
	
	@Test
	@Timeout(value = 6000, unit = TimeUnit.MILLISECONDS)
	void groupAssertions() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrecoHora precoNulo = new PrecoHora();
		assertAll("Conjunto de Afirma��es",
				() -> assertEquals(14, preco.calcular(horas)),
				() -> assertNotEquals(0, preco.calcular(horas)),
				() -> assertNull(precoNulo.getPreco_hora()),
				() -> assertThrows(NullPointerException.class, () -> {
					preco.calcular(null);
					})		
				);
	}
}
