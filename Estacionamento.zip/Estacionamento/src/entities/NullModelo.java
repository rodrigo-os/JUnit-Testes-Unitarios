package entities;
public class NullModelo extends AbstractModelo {
    @Override
    public String getModelo() {
        return "Modelo não encontrado dentre os veículos";
    }
}