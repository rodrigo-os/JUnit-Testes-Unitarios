package entities;

import static org.junit.Assume.assumeFalse;
import static org.junit.Assume.assumeTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class InteriorTest {
	static Interior cidadeInterior = new Interior(null);
	// Canoinhas
	// Mafra
	// Guarapuava
	// Pelotas
	
	
	@Test
	@Disabled
	void cidadeExistente() {
		assumeFalse(cidadeInterior.recuperarCidade("Guarapuava") == null);
		System.out.println("Guarapuava");
		assertEquals("Guarapuava", cidadeInterior.recuperarCidade("Guarapuava").getNome());	
	}
	
	
	@Test
	@Disabled
	void cidadeInexistente() {
		assertNotEquals(cidadeInterior.recuperarCidade("Mafra").getConteudo(), cidadeInterior.recuperarCidade("Canoinhas").getConteudo());
	}
	
	
	@Test
	@Disabled
	void cidadeNull() {
		assumeTrue(cidadeInterior.recuperarCidade("Tr�s Barras") == null);
		System.out.println("Tr�s Barras");
		assertNull(cidadeInterior.recuperarCidade("Tr�s Barras"));		
	}
	
	
	@Test
	@Disabled
	void cidadeException() {
		assertThrows(NullPointerException.class, () -> {
			cidadeInterior.recuperarCidade("Curitiba").getNome();
		});
	}

}
