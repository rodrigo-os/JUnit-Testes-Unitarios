package entities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class ModeloDAOTest {
	static ModeloDAO modeloDAO = new ModeloDAO();
	
	@BeforeAll
	static void inserirModelos() {
		modeloDAO.modelos.add("Logan");
		modeloDAO.modelos.add("Rebel");
		modeloDAO.modelos.add("Cruze");
		modeloDAO.modelos.add("Tiger");
	}
	
	@BeforeEach
	void visualizarModelos() {
		for(int index = 0;index<modeloDAO.modelos.size();index++) {
			System.out.println("| Modelo: "+modeloDAO.modelos.get(index)+"	"+"ID:"+index+"|");
		}
		System.out.println();
	}
		
	@Test
	void modeloReal() {
		System.out.println(modeloDAO.getModelo("Cruze"));
		assertEquals("Cruze",modeloDAO.getModelo("Cruze").modelo);
		
	}
	
	@Test
	void modeloNulo() {
		System.out.println(modeloDAO.getModelo("Corsa"));
		assertNull(modeloDAO.getModelo("Corsa").modelo);
		
	}
	
	@AfterEach
	void excluirModelo() {
		for(int count = 0;count<modeloDAO.modelos.size();count++) {
			if (modeloDAO.modelos.get(count).equalsIgnoreCase("Rebel")) {
				modeloDAO.modelos.remove(count);
			}
		}
	}
	
	@AfterAll
	static void apagarModelos() {
		System.out.println(modeloDAO.modelos);
		modeloDAO.modelos.clear();
		System.out.println(modeloDAO.modelos);
	}

}
