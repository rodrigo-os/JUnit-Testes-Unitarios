package entities;
import java.util.List;

public interface VisualizarEstacionamento {
    public String getModelo();

    public double getHoras(List<Double> horas);

    public double getPreco();
}
